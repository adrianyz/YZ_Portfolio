<?php
//collects all our finles together
require_once(mail.php);

 ?>
